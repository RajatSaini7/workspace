var express = require('express');
var router = express.Router();

/* GET users listing. */
router.post('/:userid/:password', function(req, res, next) {
  var username=req.params.userid;
  var password=req.params.password;
  res.send('Username'+username);
  res.send('Password'+password);
});

module.exports = router;
