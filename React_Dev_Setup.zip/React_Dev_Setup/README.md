# React_Dev_Setup
Dev environment setup for react web application

run the below commands from the root of the project.

npm install

npm start
